/* オリジナル音源の合成(Node だけで動く・サンプル不使用)。
   出力: dist/score/original-descent.wav(12.6秒) / original-powerdown.wav(1.98秒) / original-burst.wav(2.6秒)
   構造は参考音源と同じ: 0-5.2秒 緊張 / 5.2-7.5秒 静寂 / 7.5-11.8秒 最高潮 / 11.8秒 解放 → フェード。
   実行: node scripts/make_original_descent.mjs  (このフォルダ=リポジトリの根で) */
import fs from 'node:fs';
import path from 'node:path';

const SR = 44100;
const out = path.resolve(process.argv[2] || 'dist/score');
let seed = 20261127;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;

const buf = (sec) => new Float64Array(Math.ceil(sec * SR));
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const lerp = (a, b, p) => a + (b - a) * clamp(p, 0, 1);
const expo = (a, b, p) => a * Math.pow(b / a, clamp(p, 0, 1));

/* 足し込み: gen(t) を [start,start+dur) に加える。env(p) は 0..1 の進行で音量 */
function add(dst, start, dur, gen, env = () => 1) {
 const s0 = Math.floor(start * SR), n = Math.floor(dur * SR);
 for (let i = 0; i < n && s0 + i < dst.length; i++) { const t = i / SR, p = i / n; dst[s0 + i] += gen(t, p) * env(p, t); }
}
/* 位相を積分する発振器(周波数が時間で変わる) */
function osc(freqAt, shape = 'sine', detune = 0) {
 let ph = 0, last = -1;
 return (t) => { const f = freqAt(t) * Math.pow(2, detune / 1200); ph += f / SR; if (last < 0) last = t; const x = ph % 1;
  return shape === 'sine' ? Math.sin(x * 2 * Math.PI) : shape === 'saw' ? x * 2 - 1 : shape === 'square' ? (x < .5 ? 1 : -1) : shape === 'tri' ? 1 - 4 * Math.abs(x - .5) : Math.sin(x * 2 * Math.PI); };
}
/* RBJ biquad: 係数を64サンプルごとに更新 */
function biquad(type, freqAt, Q = .707) {
 let z1 = 0, z2 = 0, b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, k = 0;
 const set = (f) => { f = clamp(f, 20, SR * .45); const w = 2 * Math.PI * f / SR, c = Math.cos(w), s = Math.sin(w), al = s / (2 * Q); let B0, B1, B2, A0, A1, A2;
  if (type === 'lp') { B0 = (1 - c) / 2; B1 = 1 - c; B2 = (1 - c) / 2; } else if (type === 'hp') { B0 = (1 + c) / 2; B1 = -(1 + c); B2 = (1 + c) / 2; } else { B0 = al; B1 = 0; B2 = -al; }
  A0 = 1 + al; A1 = -2 * c; A2 = 1 - al; b0 = B0 / A0; b1 = B1 / A0; b2 = B2 / A0; a1 = A1 / A0; a2 = A2 / A0; };
 return (x, t) => { if ((k++ & 63) === 0) set(freqAt(t)); const y = b0 * x + z1; z1 = b1 * x - a1 * y + z2; z2 = b2 * x - a2 * y; return y; };
}
const noise = () => rnd();
const soft = (x, d = 1) => Math.tanh(x * d) / Math.tanh(d);
/* 簡易リバーブ: コム3本+オールパス1本 */
function reverb(src, wet = .25, fb = .72) {
 const combs = [1557, 1617, 1491].map(n => ({ n, b: new Float64Array(n), i: 0 }));
 const ap = { n: 225, b: new Float64Array(225), i: 0 };
 const o = new Float64Array(src.length);
 for (let i = 0; i < src.length; i++) {
  let sum = 0; for (const c of combs) { const y = c.b[c.i]; c.b[c.i] = src[i] + y * fb; c.i = (c.i + 1) % c.n; sum += y; } sum /= 3;
  const a = ap.b[ap.i], v = sum + a * .5; ap.b[ap.i] = v; ap.i = (ap.i + 1) % ap.n; const y = a - v * .5;
  o[i] = src[i] * (1 - wet) + y * wet;
 }
 return o;
}
function delayFx(src, sec, fb = .35, wet = .3) { const n = Math.floor(sec * SR), b = new Float64Array(n); let i = 0; const o = new Float64Array(src.length); for (let k = 0; k < src.length; k++) { const y = b[i]; b[i] = src[k] + y * fb; i = (i + 1) % n; o[k] = src[k] + y * wet; } return o; }
function writeWav(file, data, peakDb = -1) {
 let peak = 0; for (const v of data) peak = Math.max(peak, Math.abs(v));
 const g = Math.pow(10, peakDb / 20) / (peak || 1);
 const b = Buffer.alloc(44 + data.length * 2);
 b.write('RIFF', 0); b.writeUInt32LE(36 + data.length * 2, 4); b.write('WAVE', 8); b.write('fmt ', 12); b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(1, 22); b.writeUInt32LE(SR, 24); b.writeUInt32LE(SR * 2, 28); b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34); b.write('data', 36); b.writeUInt32LE(data.length * 2, 40);
 for (let i = 0; i < data.length; i++) b.writeInt16LE(Math.round(clamp(data[i] * g, -1, 1) * 32767), 44 + i * 2);
 fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, b); console.log('wrote', file, (data.length / SR).toFixed(2) + 's', 'peak', (20 * Math.log10(peak)).toFixed(1), 'dB raw');
}
const kick = (dst, at, level = 1, f0 = 150, f1 = 45, dur = .32) => add(dst, at, dur, (t, p) => Math.sin(2 * Math.PI * (f1 * t + (f0 - f1) * .08 * (1 - Math.exp(-t / .08)))) * Math.exp(-p * 6) * level);
const tick = (dst, at, level = 1, fc = 7000, dur = .025) => { const f = biquad('hp', () => fc, .7); add(dst, at, dur, (t, p) => f(noise(), t) * Math.exp(-p * 7) * level); };
const snare = (dst, at, level = 1) => { const f = biquad('bp', () => 1900, 1.1); add(dst, at, .18, (t, p) => (f(noise(), t) * .8 + Math.sin(2 * Math.PI * 190 * t) * .4 * Math.exp(-p * 12)) * Math.exp(-p * 9) * level); };

/* ================= 1. 降臨の音(12.6秒) ================= */
function descent() {
 const D = 12.6, a = buf(D), beat = 60 / 138, s16 = beat / 4;
 const T1 = 5.2, T2 = 7.5, T3 = 11.8;
 /* --- 緊張 0-5.2: 唸る低音・歪んだ鋸歯のパッド・刻み・上昇ノイズ --- */
 const sub = osc(t => 41 + t * 1.5), sub2 = osc(t => 82 + t * 3);
 add(a, 0, T1, (t, p) => (sub(t) * .5 + sub2(t) * .25) * (.7 + .3 * Math.sin(2 * Math.PI * (4 + p * 8) * t)), p => lerp(.12, .22, p) * (p > .985 ? (1 - p) / .015 : 1));
 const padLp = biquad('lp', t => expo(500, 5200, t / T1), 3.2);
 const saws = [osc(() => 55, 'saw', -7), osc(() => 55, 'saw', 7), osc(() => 82.4, 'saw', 5), osc(() => 110, 'saw', -4)];
 add(a, 0, T1, (t, p) => padLp(saws.reduce((s, o) => s + o(t), 0) * .25, t), p => lerp(.12, .24, p) * (p > .985 ? (1 - p) / .015 : 1));
 for (let t = 0; t < T1 - .02; t += s16) { const p = t / T1; tick(a, t, .22 + p * .45, 6500 + p * 3000); if (Math.round(t / s16) % 2 === 1) tick(a, t, .14 + p * .3, 2600, .035); if (Math.round(t / s16) % 4 === 2) tick(a, t, .12 + p * .2, 9000, .06); }
 const riseBp = biquad('bp', t => expo(380, 6500, t / T1), 1.5);
 add(a, 0, T1, (t) => riseBp(noise(), t), p => lerp(0, .5, p) * (p > .985 ? (1 - p) / .015 : 1));
 const riseTone = osc(t => expo(220, 1760, t / T1), 'tri');
 add(a, 0, T1, (t) => riseTone(t), p => lerp(0, .2, p * p) * (p > .985 ? (1 - p) / .015 : 1));
 for (const t of [0, beat * 4, beat * 8]) { kick(a, t, .55, 120, 32, .45); tick(a, t, .5, 4000, .12); const f = biquad('lp', () => 900, .8); add(a, t, .3, (tt, p) => f(noise(), tt) * Math.exp(-p * 10) * .5); }
 /* --- 静寂 5.2-7.5: 心拍が速くなる・高い粒・7.5へ向かう逆再生風の膨らみ --- */
 let hb = T1 + .25; const hbT = [];
 while (hb < T2 - .1) { hbT.push(hb); hb += Math.max(.26, .62 - (hb - T1) * .17); }
 for (const t of hbT) { kick(a, t, .4, 70, 38, .22); kick(a, t + .13, .22, 58, 34, .18); tick(a, t, .22, 9000, .02); }
 const shim = osc(t => 4200, 'sine');
 for (let k = 0; k < 7; k++) { const t = T1 + .4 + k * .3 + rnd() * .05, f = 3500 + k * 350; const o = osc(() => f); add(a, t, .25, (tt, p) => o(tt) * Math.exp(-p * 8), () => .14); }
 const swellBp = biquad('bp', t => expo(900, 7000, (t - 6.3) / 1.2), 1.2);
 add(a, 6.3, T2 - 6.3, (t) => swellBp(noise(), t), p => .4 * p * p);
 const swellSub = osc(t => 48);
 add(a, 6.3, T2 - 6.3, (t) => swellSub(t), p => .14 * p);
 /* --- 最高潮 7.5-11.8: 四つ打ち・鋸歯の和音(小節ごとに半音上げ)・高いアルペジオ・上昇ノイズ --- */
 const bars = [[110, 130.81, 164.81, 220], [116.54, 138.59, 174.61, 233.08], [123.47, 146.83, 185, 246.94]];
 const chordLp = biquad('lp', t => expo(2200, 11000, (t - T2) / (T3 - T2)), 2.0);
 const arpScale = [880, 1046.5, 1174.7, 1318.5, 1568, 1760, 2093, 2349, 2637, 3136, 3520, 4186];
 const arpBuf = buf(D);
 let i16 = 0;
 for (let t = T2; t < T3 - .05; t += s16, i16++) {
  const bar = Math.min(2, Math.floor((t - T2) / (beat * 4))), p = (t - T2) / (T3 - T2);
  if (i16 % 4 === 0) kick(a, t, .7, 160, 46, .3); if (i16 % 2 === 1) tick(a, t, .25 + p * .2, 7500, .07);
  if (i16 % 8 === 4) snare(a, t, .7);
  tick(a, t, .32 + p * .3, 8000, .02);
  const chord = bars[bar].map(f => osc(() => f, 'saw', (rnd()) * 9));
  const duck = (tt) => 1 - .6 * Math.exp(-((tt + (i16 % 4) * s16) % beat) / .09);
  add(a, t, s16 * .95, (tt, pp) => chordLp(soft(chord.reduce((s, o) => s + o(tt), 0) * .3, 1.6), t + tt) * duck(tt) * (1 - pp * .3), () => .22 + p * .12);
  const f = arpScale[(i16 * 3 + bar * 2) % arpScale.length] * (p > .66 ? 2 : 1);
  const o = osc(() => f, 'tri');
  add(arpBuf, t, s16 * 1.6, (tt, pp) => o(tt) * Math.exp(-pp * 4), () => .26 + p * .16);
 }
 const arpD = delayFx(arpBuf, beat * .75, .4, .35);
 for (let i = 0; i < a.length; i++) a[i] += arpD[i];
 const climbBp = biquad('bp', t => expo(800, 11000, (t - 9.4) / (T3 - 9.4)), 1.4);
 add(a, 9.4, T3 - 9.4, (t) => climbBp(noise(), t), p => .55 * p * p);
 const screamer = osc(t => expo(440, 3520, (t - 9.8) / (T3 - 9.8)), 'saw');
 const scLp = biquad('lp', () => 5000, 1);
 add(a, 9.8, T3 - 9.8, (t) => scLp(screamer(t), t), p => .18 * p);
 /* --- 解放 11.8: 全帯域の炸裂・落ちる低音・明るい和音 → 12.6 までフェード --- */
 const bLp = biquad('lp', t => expo(14000, 250, (t - T3) / .9), .6);
 add(a, T3, D - T3, (t) => bLp(noise(), t), p => .9 * Math.exp(-p * 3));
 add(a, T3, .9, (t, p) => Math.sin(2 * Math.PI * (36 * t + (260 - 36) * .12 * (1 - Math.exp(-t / .12)))) * Math.exp(-p * 3.5) * .6);
 for (const [k, f] of [1046.5, 1318.5, 1568, 2093].entries()) { const o = osc(() => f); add(a, T3 + .02 + k * .025, D - T3 - .05, (t, p) => o(t) * Math.exp(-p * 2.2), () => .18); }
 const r = reverb(a, .18, .7);
 for (let i = 0; i < a.length; i++) { const p = i / a.length; a[i] = soft(r[i] * .9, 1.3) * (p > .95 ? (1 - p) / .05 : 1); }
 return a;
}
/* ================= 2. プチュン(1.98秒) ================= */
function powerdown() {
 const D = 1.98, a = buf(D);
 add(a, 0, .006, () => .8);
 add(a, 0, .34, (t, p) => Math.sin(2 * Math.PI * expo(3200, 48, p) * t * (1 - p * .5)) * (1 - p * .2), () => .9);
 const bp = biquad('bp', t => expo(3800, 90, t / .36), 2.5);
 add(a, 0, .36, (t) => bp(noise(), t), () => .5);
 const whine = osc(() => 12500);
 add(a, 0, .55, (t) => whine(t), p => .06 * Math.exp(-p * 5));
 const rum = biquad('lp', t => expo(700, 60, (t - .25) / .65), .9);
 add(a, .25, .68, (t) => rum(noise(), t), p => .45 * Math.exp(-p * 2.2));
 add(a, .28, .5, (t, p) => Math.sin(2 * Math.PI * 44 * t) * Math.exp(-p * 4) * .5);
 const cut = Math.floor(.93 * SR); for (let i = cut; i < a.length; i++) a[i] = 0;
 for (let i = cut - 90; i < cut; i++) a[i] *= (cut - i) / 90;
 return a;
}
/* ================= 3. 炸裂(2.6秒) ================= */
function burst() {
 const D = 2.6, a = buf(D);
 const lp = biquad('lp', t => expo(15000, 220, t / 1.4), .6);
 add(a, 0, 1.5, (t) => lp(noise(), t), p => .9 * Math.exp(-p * 3.2));
 const hp = biquad('hp', () => 5000, .5);
 add(a, 0, .3, (t) => hp(noise(), t), p => .5 * Math.exp(-p * 6));
 add(a, 0, .9, (t, p) => Math.sin(2 * Math.PI * (34 * t + (210 - 34) * .1 * (1 - Math.exp(-t / .1)))) * Math.exp(-p * 3.5) * .9);
 const chordB = buf(D);
 for (const [k, f] of [1046.5, 1318.5, 1568, 2093, 2637].entries()) { const o = osc(() => f); add(chordB, .03 + k * .03, D - .2, (t, p) => o(t) * Math.exp(-p * 2.4), () => .12); }
 for (let k = 0; k < 22; k++) { const t = .05 + k * .045 + Math.abs(rnd()) * .02, f = 2500 + Math.abs(rnd()) * 4500; const o = osc(() => f); add(chordB, t, .35, (tt, p) => o(tt) * Math.exp(-p * 7), () => .07); }
 const cd = reverb(delayFx(chordB, .19, .4, .4), .3, .74);
 for (let i = 0; i < a.length; i++) { const p = i / a.length; a[i] = soft(a[i] + cd[i], 1.3) * (p > .9 ? (1 - p) / .1 : 1); }
 return a;
}

writeWav(path.join(out, 'original-descent.wav'), descent(), -1);
writeWav(path.join(out, 'original-powerdown.wav'), powerdown(), -3);
writeWav(path.join(out, 'original-burst.wav'), burst(), -2);
