# 播州めだか ガチャ演出・Claude引き継ぎ

確認URL: https://banshu-medaka-gacha.fabled-bead-3587.chatgpt.site/?v=49
ソース版: 20af3d1764ae1fdb36629e2a8eea2acec7779f5c

## v50(2026-11-27 ゴッド改修)
変更内容は 変更内容_v50_20261127.md。追加=dist/v50-impact.js, dist/v50-impact.css。作り直し=dist/descent-fx.js。小修正=score.js, freeze-patterns.js, gacha-rules.js, 両HTML。
フリーズの長さと高域ブースト量は v50-impact.js 先頭の V50 で変えられる。
音源: プチュン・降臨・炸裂は scripts/make_original_descent.mjs で合成したオリジナル(wav)。動画から抽出した参考音源(reference-*)は権利未確認のため同梱していない。

## 起動
ZIPを展開し、このREADMEがあるフォルダで次を実行します。
python3 -m http.server 8000 --directory dist
ブラウザで http://localhost:8000 を開きます。ビルド不要です。
音声の読み込みがあるためHTMLの直接起動ではなくHTTPで確認してください。
スタート操作で音声を有効化します。端末の音量・マナーモードも確認してください。

## 編集箇所
- dist/index.html / reel.js / reel.css: メイン画面、龍・祝福
- dist/sword-reference.html / .js / .css: 炎演出（iframe）
- dist/freeze-patterns.js: フリーズのタイミングと進行
- dist/descent-fx.js / lightning-fx.js: 亀裂・エネルギー・稲妻
- dist/score.js / audio-unlock.js: 音源の読み込みと再生
- dist/impact-type.css: 迫力文字・届かず
- dist/opening-reveal.css: 開始時の大きなビジュアル
- dist/button-anticipation.js: PUSH出現の煽り
- dist/rainbow.css: 虹色メダカ
- dist/logo-rig.js / .css: ロゴ役物
- dist/gacha-rules.js: 演出とランクの選択
- scripts/: 音源制作補助。通常再生には不要。再生成にはPython音声処理環境等が必要。
画像・MP3を含めてdist全体を保持してください。

## 継続する演出方針
1. 炎・龍・祝福の3パターンを区別する。開始BGMも3種類別々。
2. 炎は剣と炎、龍は龍の目と青い稲妻、祝福は黄金の封印・宝箱・花びら。
3. フリーズの発生タイミングは複数。フリーズ後に通常のプレミア演出を重複再生しない。
4. プチュン→約3秒の暗転→亀裂とエネルギー約10秒→虹色→景品。
5. (v50)参考音源は使わず、同じ構造のオリジナル score/original-*.wav に差し替え済み。演出との同期(静寂5.2〜7.5秒・解放11.8秒)を保つ。
6. BGMは重低音偏重を避け、高音が目立つ激しくワクワクする方向。現在の開始音はopening-*-bright.mp3。
7. 虹色メダカは画面内に収め、「おめでとう！」も表示。
8. PUSHの前に「出るか出ないか」の煽りを入れる。
9. 開始時の小さなカード表現を、大きく迫力のある剣・龍・宝箱に変更済み。
10. 稲妻は不規則な枝分かれ、白い芯と発光でリアルに。文字は太い縁・立体感・衝撃。「届かず…」にも迫力を付ける。

## 確認上の注意
炎・龍・祝福の通常とフリーズ、PUSH分岐、スマートフォンでの収まり、音声、景品への遷移を確認してください。
実機iPhoneでの動作保証を意味しません。実機確認は別途必要です。
景品・抽選表示はデモ用途です。決済・在庫連携はこの引き継ぎの対象ではありません。
公開先の認証情報やGit履歴は同梱していません。変更しても公開サイトへ自動反映されません。
